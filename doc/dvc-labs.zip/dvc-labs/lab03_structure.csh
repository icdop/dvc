#!/bin/csh -f
# lab03 · 五層目錄與 DVC_PATH（技術主管铺路）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

cd $TRAIN_ROOT/users/u01

echo "##### STEP 1  一次鋪滿四層"
dvc_create_folder P1-trial/chip/000-DATA/2021_0301-foundation
dvc_checkout_folder  P1-trial/chip/000-DATA/2021_0301-foundation
ls -a ; ls -a _/P1-trial/chip/000-DATA/

echo "##### STEP 2  逐層建立（等價寫法）"
dvc_create_phase  P2-stable
dvc_create_block  cpu
dvc_create_stage  400-APR
dvc_create_version 2021_0512-impl005

echo "##### STEP 3  佔位符：_ 與 . 沿用當前層"
dvc_set_folder _/_/_/2021_0519-eco
dvc_get_folder --info
dvc_create_version 2021_0519-eco
dvc_list_stage 400-APR

echo "##### STEP 4  看整棵樹（本機 tree / 伺服器清單）"
dvc_list_folder
dvc_list_project $PRJ_ID
