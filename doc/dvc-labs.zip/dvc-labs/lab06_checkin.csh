#!/bin/csh -f
# lab06 · 提交的四种粒度：commit / checkin_container / checkin_version / checkin_folder
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

set W = $TRAIN_ROOT/users/u06
if ( ! -d "$W" ) then
    mkdir -p $W
endif
cd $W
dvc_checkout_project $PRJ_ID _ > /dev/null

echo "##### STEP 1  制造三种待提交状态：新增 / 改名 / 临时垃圾"
dvc_checkout_folder P2-stable/cpu/400-APR/2021_0519-eco >& /dev/null
dvc_set_container .
dvc_copy_object $LAB_DATA/cpu.v  cpu.v
dvc_copy_object $LAB_DATA/reports/sta.rpt sta.rpt
mkdir -p $LAB_HOME/train/scratch && cd $LAB_HOME/train/scratch && touch log.0 log.1 core.1234 && set W = $TRAIN_ROOT/users/u06
if ( ! -d "$W" ) then
    mkdir -p $W
endif
cd $W
dvc_checkout_project $PRJ_ID _ > /dev/null
dvc_copy_object $LAB_HOME/train/scratch/ cache/          # 故意把垃圾目录也收进来
svn status :version | grep -v "^?" | sed 's/:version//'

echo "##### STEP 2  先清理，再精确 commit（推荐姿势）"
dvc_delete_object cache
dvc_commit_container .
echo "--- 提交后服务器内容："
dvc_list_container .

echo "##### STEP 3  版本级提交：连 .dvc / .dqi / .htm 一起入库"
dvc_set_dqi --root :version WNS -0.412 >& /dev/null
dvc_checkin_version 2021_0519-eco
echo "--- 服务器上的版本目录："
svn list file://$SVN_ROOT/$PRJ_ID/P2-stable/cpu/400-APR/2021_0519-eco/

echo "##### STEP 4  整条路径逐级提交（父层先于子层）"
dvc_copy_object $LAB_DATA/cpu.sdc design.sdc
dvc_checkin_folder P2-stable/cpu/400-APR/2021_0519-eco | egrep "INFO|Committed"

echo "[CHECK] 1) delete 之后要 commit 才生效 2) checkin_* 会连 .dvc/.dqi/.htm 一起入库 3) checkin_folder 按 phase→version 逐级提交"
