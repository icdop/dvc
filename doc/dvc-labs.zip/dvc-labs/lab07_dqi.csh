#!/bin/csh -f
# lab07 · DQI 质量指标：写入、读取、分组、跨版本趋势、HTML 报表
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

set W = $TRAIN_ROOT/users/u07
mkdir -p $W; cd $W
dvc_checkout_project $PRJ_ID _ > /dev/null
dvc_create_folder  P2-stable/cpu/500-TIMING/2021_0601-rc0 > /dev/null
dvc_checkout_folder P2-stable/cpu/500-TIMING/2021_0601-rc0 | grep "Checkout Project Design Version"

echo "##### STEP 1  写入版本级指标（每行都有 DQI: 回显）"
dvc_set_dqi --root :version WNS -0.152
dvc_set_dqi --root :version TNS -3.418
dvc_set_dqi --root :version DRC 12
dvc_set_dqi --root :version UTIL 0.86

echo "##### STEP 2  分组指标（path group）"
dvc_set_dqi --root :version --group REG2REG   WNS -0.098
dvc_set_dqi --root :version --group REG2MACRO WNS -0.241
dvc_set_dqi --root :version MACRO2REG/WNS -0.412
echo "--- 不带值调用 = 打印这棵 .dqi 树："
dvc_set_dqi --root :version

echo "##### STEP 3  读取：单值 / 全部 / 指定格式"
echo "-- 单值：       " `dvc_get_dqi --root :version WNS`
dvc_get_dqi --root :version --script --all
dvc_get_dqi --root :version --group REG2REG --csv --all

set RC0 = $W/_/P2-stable/cpu/500-TIMING/2021_0601-rc0
echo "##### STEP 4  跨版本趋势（评审会就用这几行）"
dvc_create_version 2021_0610-rc1 > /dev/null
dvc_checkout_version 2021_0610-rc1 > /dev/null
dvc_set_dqi --root :version WNS -0.152 > /dev/null
dvc_checkin_version 2021_0610-rc1 > /dev/null
foreach v ( 2021_0601-rc0 2021_0610-rc1 )
  set p = "$W/_/P2-stable/cpu/500-TIMING/$v/.dqi/WNS"
  echo "$v  WNS =`cat $p`"
end

echo "##### STEP 5  产出 HTML 质量表（可直接嵌入评审材料）"
dvc_get_dqi --root $RC0 --group REG2REG --html --all > $LAB_OUT/lab07_wns_table.html
cat $LAB_OUT/lab07_wns_table.html

echo "##### STEP 6  指标随数据一起入库"
dvc_checkin_version 2021_0601-rc0 | egrep "Committed|Sending|Adding" | head -4
svn cat file://$SVN_ROOT/$PRJ_ID/P2-stable/cpu/500-TIMING/2021_0601-rc0/.dqi/WNS

set SV = file://$SVN_ROOT/$PRJ_ID/P2-stable/cpu/500-TIMING/2021_0601-rc0/.dqi
echo "--- 服务器上的指标（这才是团队资产）："; svn cat $SV/WNS
echo "[CHECK] 指标 = .dqi 下的纯文本文件；不 checkin 只在你本机存在"
