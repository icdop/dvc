#!/bin/csh -f
# lab05 · 容器與对象：copy / link / rename / delete（设计工程师核心）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

cd $TRAIN_ROOT/users/u01
dvc_checkout_folder P2-stable/cpu/400-APR/2021_0512-impl005 >& /dev/null

echo "##### STEP 1  一个版本下开多个容器（按 step 划分）"
dvc_create_container place
dvc_create_container route
dvc_list_version

echo "##### STEP 2  当前容器：set_container 改的是 :container 链接"
dvc_set_container route
ls -l :container | grep container
echo "--- 容器实目录："
ls -ld :version/route

echo "##### STEP 3  小檔 copy：数据实体进容器"
dvc_copy_object $LAB_DATA/cpu.v   cpu.v
dvc_copy_object $LAB_DATA/cpu.sdc constraint.sdc
dvc_copy_object $LAB_DATA/reports/ report
echo "--- 本地容器目录："
ls :version/route

echo "##### STEP 4  大檔用 link：入库的只是一个链接条目"
gzip -c $LAB_DATA/cpu.v > $TRAIN_ROOT/bigfile.spef.gz
dvc_link_object $TRAIN_ROOT/bigfile.spef.gz design.spef.gz
ls -l :version/route/design.spef.gz
echo "--- 仓库里存的是 symlink，不是 300MB 内容 —— 跨机共享会失效"

echo "##### STEP 5  rename / delete（只改本地工作副本）"
dvc_rename_object constraint.sdc design.sdc
dvc_delete_object report/apr.log
echo "--- svn status 看本地待提交变更："
svn status :version/route | grep -v "^?" | sed 's/:version\/route//'

echo "##### STEP 6  checkin 之前 vs 之后（团队可见性的分界线）"
echo "--- 仓库里现在有什么（服务器视角）："
dvc_list_container route
dvc_checkin_container route
echo "--- checkin 之后："
dvc_list_container route

echo "[CHECK] 1) copy/link/rename/delete 只动本地 2) checkin 之前别人看不见 3) link 条目不可跨机共享"
