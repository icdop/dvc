#!/bin/csh -f
# 依序執行全部 lab，並把回顯寫進 logs/
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
mkdir -p $LAB_HOME/logs
rm -rf $LAB_HOME/train
foreach f ( lab01_server lab02_project lab03_structure lab04_checkout lab05_objects lab06_checkin lab07_dqi lab08_share lab09_scenario lab10_recovery )
    echo ">>> $f"
    csh $LAB_HOME/$f.csh >& $LAB_HOME/logs/$f.log
    if ($status != 0) echo "    ** $f 退出碼 $status"
end
csh $LAB_HOME/verify.csh | tee $LAB_HOME/logs/verify.log
