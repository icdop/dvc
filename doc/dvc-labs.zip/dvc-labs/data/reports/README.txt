Sample reports used by the DVC hands-on labs.
