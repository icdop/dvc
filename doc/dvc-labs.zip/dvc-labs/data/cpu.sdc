# sample timing constraint
create_clock -name clk -period 0.500 [get_ports clk]
set_input_delay  0.150 -clock clk [all_inputs]
set_output_delay 0.150 -clock clk [all_outputs]
set_driving_cell -lib_cell INVX2 [all_inputs]
