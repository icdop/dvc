// sample netlist for DVC hands-on lab
module cpu (clk, rst_n, req, gnt, status);
  input         clk, rst_n, req;
  output        gnt;
  output [7:0]  status;
  wire [7:0]    st;
  assign  gnt   = req & rst_n;
  assign  st    = {req, rst_n, 6'b0};
  reg  [7:0]  status;
  always @(posedge clk) status <= st;
endmodule
