#!/bin/csh -f
# 全课自检：只用命令验证「数据是否真的进了仓库」
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh
set S = file://$SVN_ROOT/$PRJ_ID

echo "=== A. 目录骨架"
foreach p ( P1-trial P2-stable P3-final )
  svn info $S/$p >& /dev/null
  if ($status == 0) then
    echo "OK    phase $p"
  else
    echo "MISS  phase $p"
  endif
end
foreach v ( P2-stable/cpu/400-APR/2021_0512-impl005  P2-stable/cpu/500-TIMING/2021_0610-rc1  P3-final/chip/700-TAPEOUT/2021_0818-golden )
  svn info $S/$v >& /dev/null
  if ($status == 0) then
    echo "OK    version $v"
  else
    echo "MISS  version $v"
  endif
end

echo "=== B. 交付凭据（数据 + 指标 + 状态）"
svn cat $S/P3-final/chip/700-TAPEOUT/2021_0818-golden/.dqi/WNS >& /dev/null
if ($status == 0) then
  echo "OK    golden 的 DQI 已入库，WNS =" `svn cat $S/P3-final/chip/700-TAPEOUT/2021_0818-golden/.dqi/WNS`
else
  echo "MISS  golden DQI 未入库"
endif
svn cat $S/.dqi/NETLIST_STATE >& /dev/null || echo "INFO  项目级指标可另行 checkin_project"
echo "OK    golden 文件树："
svn list $S/P3-final/chip/700-TAPEOUT/2021_0818-golden | head -6

echo "=== C. 规模统计"
echo "全项目条目 = " `svn list -R $S | wc -l` ",  APR 版本内文件 = " `svn list -R $S/P2-stable/cpu/400-APR/2021_0512-impl005 | grep -v '/.*$' | wc -l`
echo "修订号进度 = r" `svn info $S | grep "^Revision" | awk '{print $2}'`

echo "=== D. 接收方视角（lab08 建立的 work/pkgA 工作区）"
if ( -d $TRAIN_ROOT/work/pkgA/_ ) then
  cd $TRAIN_ROOT/work/pkgA
  dvc_set_project $PRJ_ID > /dev/null
  echo "OK    接收方可列出：" `dvc_list_project $PRJ_ID | tr '\n' ' '`
else
  echo "MISS  接收方工作区不存在（先跑 lab08）"
endif
echo "自检结束：上面若全部 OK，说明数据、指标、凭据都真的进了仓库"
