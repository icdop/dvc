#!/bin/csh -f
# lab02 · 專案與上下文（PM 與工程師都要會）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

echo "##### STEP 1  把專案掛到自己的工作區（預設僅 files 深度）"
cd $TRAIN_ROOT; mkdir -p users/u01; cd users/u01
dvc_checkout_project $PRJ_ID _
ls -a
echo "--- 本地記住的上下文："
dvc_get_env --all
dvc_get_project --info

echo "##### STEP 2  上下文變數：set / get"
dvc_set_project $PRJ_ID
dvc_set_env --server TECHLIB $LAB_HOME/data
dvc_get_server --info
dvc_list_project $PRJ_ID

echo "##### STEP 3  兩個工作區共存（模擬兩人）"
cd $TRAIN_ROOT; mkdir -p users/u02; cd users/u02
dvc_checkout_project $PRJ_ID _
dvc_get_project --info

echo "[CHECK] 兩人各自的 _ 目錄與 .dop/env 互相獨立；--server 變數共享於倉庫"
