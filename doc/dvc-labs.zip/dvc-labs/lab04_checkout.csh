#!/bin/csh -f
# lab04 · 检出與 : 链接（工程师每天开门动作）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

cd $TRAIN_ROOT/users/u01

echo "##### STEP 1  按四層路徑检出"
dvc_checkout_folder P2-stable/cpu/400-APR/2021_0512-impl005

echo "##### STEP 2  自動造的五个 : 链接"
ls -l | egrep "^(l|total)|:" | head -20
echo "--- 每个链接指向："

echo "##### STEP 3  用链接直接引用路徑"
set v = `readlink :version`; echo ":version -> $v"
ls $v | head
echo "--- 检出深度預設为 files：注意版本目錄下暫無大檔"

echo "##### STEP 4  只換版本，不動其他層"
dvc_checkout_folder ._._._ >& /dev/null
dvc_set_folder 2021_0519-eco
dvc_get_folder --info
dvc_checkout_version 2021_0519-eco
readlink :version

echo "[CHECK] 換版本後 :version 与 _ 链接同步改指，不需重打完整路徑"
