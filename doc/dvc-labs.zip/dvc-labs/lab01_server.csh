#!/bin/csh -f
# lab01 · 起一個可執行的 SVN 倉庫環境（CAD / IT 角色）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

echo ""
echo "##### STEP 1  命令是否可用"
dvc_get_system
which dvc_create_project

echo "##### STEP 2  file 模式初始化（不啟服務進程）"
dvc_init_server --root $SVN_ROOT --mode file
dvc_get_server --info

echo "##### STEP 3  建立專案倉庫"
dvc_create_project $PRJ_ID

echo "##### STEP 4  倉庫裡多了什麼"
svn list file://$SVN_ROOT/$PRJ_ID/
echo "--- 元資料目錄 .dvc/env/ 內容："
svn list file://$SVN_ROOT/$PRJ_ID/.dvc/env/
echo "--- 專案級 README："
svn cat file://$SVN_ROOT/$PRJ_ID/.dvc/README

echo "[CHECK] 上面應看到 .dvc / .dqi / .htm 三個元資料目錄（conf/ 在倉庫目錄層，不在版本樹裡） + README 里的建立者與時間"
