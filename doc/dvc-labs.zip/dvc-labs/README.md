# DVC 實作訓練 · 可執行案例資料（dvc-labs）

配套《DVC 實作訓練課程》（120+ 頁講義）。全部 lab 均已在
Linux + tcsh 6.24 + Subversion 1.14 + GNU make 環境實際執行通過，
`logs/` 內是每次執行留下的真實回显，可直接與幻燈對照。

## 1. 前置條件

| 項目 | 要求 | 檢查命令 |
|---|---|---|
| 作業系統 | Linux / Unix（DVC 是 tcsh 腳本，不能直接在 bash 裡 source 環境檔） | `echo $SHELL` |
| shell | tcsh 或 csh | `csh --version` |
| Subversion | 提供 `svn` / `svnadmin` / `svnserve` | `svn --version` |
| GNU make、git | 建置命令、取原始碼 | `make -v` |
| DVC 原始碼 | 需先 `make bin` 產生 66 支命令 | `dvc_get_system` |

取得並建置 DVC：

```csh
cd /tools/icdop                      # 或任何共用工具區
git clone https://gitee.com/icdop/dvc.git
cd dvc && make bin
```

## 2. 三分鐘跑通

```csh
csh> cd dvc-labs
csh> csh lab01_server.csh                   # 單課執行
csh> csh run_all.csh                         # 全套依序執行（回顯進 logs/）
csh> csh verify.csh                          # 只驗收：資料是否真的進了倉庫
```

DVC_HOME 由 `env.csh` 按三個順序自動解析，一般不用管；若要手動指定，在執行前：

```csh
csh> setenv DVC_HOME /tools/icdop/dvc       # 優先級最高，跳過自動探測
```

## 3. 目錄

```
dvc-labs/
├── README.md              本檔
├── env.csh                環境：DVC_HOME / SVN_ROOT / 專案號（可被外部覆寫）
├── run_all.csh            依序執行全部 lab + verify
├── verify.csh             最終自檢（全部用命令驗收，不看螢幕）
├── data/                  樣本設計資料（网表 / 约束 / 报告），lab 的輸入
│   ├── cpu.v  cpu.sdc  ip_list.csv
│   └── reports/{sta.rpt, drc.rpt, apr.log}
├── lab01_server.csh       起仓库（CAD/IT 角色）
├── lab02_project.csh      建專案 + 雨个工作区
├── lab03_structure.csh    五层目录 / DVC_PATH / 占位符
├── lab04_checkout.csh     检出、: 链接、深度
├── lab05_objects.csh      容器 + copy / link / rename / delete / checkin
├── lab06_checkin.csh      commit / checkin_container / checkin_version / checkin_folder
├── lab07_dqi.csh          DQI：写入、分组、--csv/--html、跨版本趋势
├── lab08_share.csh        跨团队共享：交付三件套 + 接收方接手 + 回写
├── lab09_scenario.csh     综合演练：SoC 从 000-DATA 到 700-TAPEOUT
├── lab10_recovery.csh     危险操作、peg revision 恢复、dump/load 迁移
├── logs/                  真实执行回显（与讲义逐页对应）
└── train/                 执行期产物（可随时删除重跑）
```

## 4. 与讲义的对应关系

讲义每一节的「動手」页都标注了对应 lab 与 STEP；
`logs/labNN_*.log` 里的行就是该页展示的终端回显来源。

| 讲义模块 | lab | 讲义页 |
|---|---|---|
| M1 仓库与项目 | lab01, lab02 | 17–28 |
| M2 目录与命名 | lab03 | 29–39 |
| M3 检出与上下文 | lab04 | 40–52 |
| M4 对象与容器 | lab05 | 53–68 |
| M5 提交与复核 | lab06 | 69–79 |
| M6 质量指标 | lab07 | 80–88 |
| M7 跨团队共享 | lab08 | 89–104 |
| M8 权限·追溯·恢复 | lab10 | 105–114 |
| M9 综合演练 | lab09 | 115–121 |

## 5. 已知环境限制（重要，讲义 M8 也有专页）

1. **DVC 为早期 SVN（每目录 `.svn`）编写**；SVN 1.7+ 是单一 `.svn` 布局。
   反复对同一路径做嵌套检出可能遗留写入锁，症状是
   `svn: E155037: Previous operation has not finished; run 'cleanup'`。
   处置：对**检出根**执行 `svn cleanup _`（lab10 STEP0 已示范）。
2. **`dvc_link_object` 记录的是本机 realpath 绝对路径** → 跨机/跨挂载点必失效。
   凡是要给别人的数据，一律 `dvc_copy_object`。
3. **`dvc_remove_project` 是 `rm -rf $SVN_ROOT/<project>`**，连 SVN 历史一起消失，
   只可在测试环境使用；本套 lab 不会执行它。
4. `dvc_get_dqi` 的格式选项需写在 `--all` 之前（`--html --all`），
   这是脚本参数解析顺序决定的。
5. lab 会以本机端口 14321 启动 `svnserve`（lab08），结束后可用
   `dvc_init_server stop` 关闭。

## 6. 重置

```csh
rm -rf train logs        # 全部产物删除，重跑即回到初始状态
```
