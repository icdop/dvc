# /bin/csh -f
# DVC 実訓 · 環境檔（每個 lab 開頭都要 source 這一行）
# 用法：  source /path/to/dvc-labs/env.csh
#
# 可覆寫：  setenv LAB_SVN_ROOT /your/path  （在 source 之前設定即可）

# DVC_HOME 解析順序： 外部 setenv → $LAB_HOME/../dvc → /tools/icdop/dvc
if ($?DVC_HOME == 0) then
    if ($?LAB_HOME == 0) then
        set _d = `dirname "$0"`
        setenv LAB_HOME `cd $_d && pwd`
    endif
    if ( -d "$LAB_HOME/../dvc/bin" ) then
        setenv DVC_HOME `cd $LAB_HOME/../dvc && pwd`
    else if ( -d "/tools/icdop/dvc/bin" ) then
        setenv DVC_HOME /tools/icdop/dvc
    else
        setenv DVC_HOME "$LAB_HOME/../dvc"
    endif
endif
if (! -d "$DVC_HOME/bin" ) then
    echo "ERROR: DVC_HOME=$DVC_HOME 裡沒有 bin/"
    echo "       解決： cd <dvc 源碼目錄> && make bin   或  setenv DVC_HOME <路徑>"
    exit 1
endif

if ($?LAB_HOME == 0) then
    set _d = `dirname "$0"`
    setenv LAB_HOME `cd $_d && pwd`
endif
setenv PATH      "$DVC_HOME/bin:$PATH"

setenv TRAIN_ROOT  $LAB_HOME/train
if ($?LAB_SVN_ROOT) then
    setenv SVN_ROOT  $LAB_SVN_ROOT
else
    setenv SVN_ROOT  $TRAIN_ROOT/svn
endif

setenv SVN_MODE    file
if ($?LAB_SVN_MODE) then
    setenv SVN_MODE $LAB_SVN_MODE
endif
setenv SVN_HOST    localhost
setenv SVN_PORT    14321                       # lab08 的 svn 模式端口（避開 3690）
setenv PRJ_ID      N7A                          # 練習用專案代號

setenv LAB_DATA    $LAB_HOME/data
setenv LAB_OUT     $TRAIN_ROOT/out
mkdir -p $LAB_OUT

echo "=== DVC HANDS-ON LAB ENV ==="
echo "DVC_HOME    = $DVC_HOME   (`dvc_get_system | tail -1`)"
echo "LAB_HOME    = $LAB_HOME"
echo "TRAIN_ROOT  = $TRAIN_ROOT"
echo "SVN_ROOT    = $SVN_ROOT   (SVN_MODE=$SVN_MODE)"
echo "現在工作目錄 = $cwd"
echo "開始：  csh lab01_server.csh"
