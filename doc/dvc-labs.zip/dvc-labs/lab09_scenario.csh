#!/bin/csh -f
# lab09 · 综合剧本：一颗 SoC 从数据准备到 Tapeout 的完整数据管理
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

set W = $TRAIN_ROOT/users/u09
mkdir -p $W; cd $W
dvc_checkout_project $PRJ_ID _ > /dev/null
set P = $W/_

echo "==================== M0 · 000-DATA 数据准备"
dvc_create_folder P1-trial/chip/000-DATA/2021_0301-foundation | grep "Create Project" | tail -1
dvc_checkout_folder P1-trial/chip/000-DATA/2021_0301-foundation > /dev/null
dvc_copy_object $LAB_DATA/cpu.v top.v | tail -1
dvc_copy_object $LAB_DATA/ip_list.csv ip_list.csv | tail -1
dvc_copy_object $LAB_DATA/cpu.sdc constraint.sdc | tail -1
dvc_checkin_folder P1-trial/chip/000-DATA/2021_0301-foundation | grep Committed

echo "==================== M1 · 100-CIRCUIT 综合迭代（每晚一版，只增不改）"
set syn = ( "2021_0315-syn001 -0.842" "2021_0322-syn002 -0.412" "2021_0329-syn003 -0.207" )
foreach row ( $syn )
  set v = `echo $row | cut -d' ' -f1`
  set w = `echo $row | cut -d' ' -f2`
  dvc_create_folder P1-trial/chip/100-CIRCUIT/$v | grep "Create Project Design Version"
  dvc_checkout_folder P1-trial/chip/100-CIRCUIT/$v > /dev/null
  dvc_copy_object $LAB_DATA/cpu.v cpu.v > /dev/null
  dvc_copy_object $LAB_DATA/reports/sta.rpt sta.rpt > /dev/null
  dvc_set_dqi --root :version WNS   $w   > /dev/null
  dvc_set_dqi --root :version TNS   -8.2 > /dev/null
  dvc_set_dqi --root :version CELLS 1.8M > /dev/null
  dvc_checkin_version $v > /dev/null
  echo "   $v  WNS = `dvc_get_dqi --root :version WNS`   服务器已可见"
end

echo "==================== M2 · 200-FUNCTION 功能验证（testbench 作容器）"
dvc_create_folder P1-trial/cpu/200-FUNCTION/2021_0412-fv003 | grep "Create Project Design Version"
dvc_checkout_folder P1-trial/cpu/200-FUNCTION/2021_0412-fv003 > /dev/null
set tbs  = ( base dft stress boot )
set fail = ( 0 3 1 0 )
set cov  = ( 98.4 96.1 92.7 99.0 )
set i = 1
foreach tb ( $tbs )
  dvc_create_container $tb > /dev/null
  dvc_copy_object $LAB_DATA/reports/drc.rpt summary.rpt > /dev/null
  dvc_set_dqi --root :container FAIL `echo $fail[$i]` > /dev/null
  dvc_set_dqi --root :container COV  `echo $cov[$i]`  > /dev/null
  dvc_checkin_container $tb > /dev/null
  @ i = $i + 1
end
echo "   容器清单：`dvc_list_version | tr '\n' ' '`"

echo "==================== M3 · 300-DFT 插入"
dvc_create_folder P1-trial/cpu/300-DFT/2021_0425-scan002 > /dev/null
dvc_checkout_folder P1-trial/cpu/300-DFT/2021_0425-scan002 > /dev/null
dvc_copy_object $LAB_DATA/cpu.v cpu_scan.v > /dev/null
dvc_set_dqi --root :version SCAN_COV 98.7 > /dev/null
dvc_set_dqi --root :version LEC PASS > /dev/null
dvc_checkin_version 2021_0425-scan002 | grep Committed

echo "==================== M4 · 400-APR 实现（step 作容器）"
dvc_create_folder P2-stable/cpu/400-APR/2021_0512-impl005 > /dev/null
dvc_checkout_folder P2-stable/cpu/400-APR/2021_0512-impl005 > /dev/null
set steps = ( floorplan place cts route postroute )
set drcs  = ( 0 41 28 12 3 )
set i = 1
foreach st ( $steps )
  dvc_create_container $st > /dev/null
  dvc_copy_object $LAB_DATA/cpu.sdc design.sdc > /dev/null
  dvc_copy_object $LAB_DATA/reports/ report > /dev/null
  dvc_set_dqi --root :container DRC  `echo $drcs[$i]` > /dev/null
  dvc_set_dqi --root :container UTIL 0.86 > /dev/null
  dvc_checkin_container $st > /dev/null
  @ i = $i + 1
end
dvc_checkin_version 2021_0512-impl005 | grep Committed
echo "   step 容器：`dvc_list_version | tr '\n' ' '`"

echo "==================== M5 · 500-TIMING 多 corner 签核"
dvc_create_folder P2-stable/cpu/500-TIMING/2021_0610-rc1 > /dev/null
dvc_checkout_folder P2-stable/cpu/500-TIMING/2021_0610-rc1 > /dev/null
set cns = ( tt_0p80V_25C ss_0p72V_125C ff_0p88V_m40C mc_mmcc )
set wns = ( -0.021 -0.152 -0.004 -0.087 )
set i = 1
foreach c ( $cns )
  dvc_create_container $c > /dev/null
  dvc_copy_object $LAB_DATA/reports/sta.rpt timing.rpt > /dev/null
  dvc_set_dqi --root :container WNS `echo $wns[$i]` > /dev/null
  dvc_set_dqi --root :container TNS -3.418 > /dev/null
  dvc_checkin_container $c > /dev/null
  @ i = $i + 1
end
dvc_checkin_version 2021_0610-rc1 > /dev/null
echo "   签核汇总（WNS）："
foreach c ( $cns )
  echo "     $c = `dvc_get_dqi --root $P/P2-stable/cpu/500-TIMING/2021_0610-rc1/$c/.dqi WNS`"
end

echo "==================== M6 · 600-POWER 功耗签核"
dvc_create_folder P3-final/chip/600-POWER/2021_0708-pw002 > /dev/null
dvc_checkout_folder P3-final/chip/600-POWER/2021_0708-pw002 > /dev/null
foreach m ( idle func_peak io_toggle )
  dvc_create_container $m > /dev/null
  dvc_copy_object $LAB_DATA/reports/apr.log power.rpt > /dev/null
  dvc_set_dqi --root :container DYN_POWER 0.42 > /dev/null
  dvc_checkin_container $m > /dev/null
end
dvc_checkin_version 2021_0708-pw002 | grep Committed

echo "==================== M7 · 700-TAPEOUT golden 交付 + 凭据三件套"
set G = P3-final/chip/700-TAPEOUT/2021_0818-golden
dvc_create_folder $G > /dev/null
dvc_checkout_folder $G > /dev/null
dvc_copy_object $LAB_DATA/cpu.v chip.v > /dev/null
dvc_copy_object $LAB_DATA/reports/ report > /dev/null
dvc_set_dqi --root :version WNS -0.008  > /dev/null
dvc_set_dqi --root :version DRC 0       > /dev/null
dvc_set_dqi --root :version LVS PASS    > /dev/null
dvc_checkin_version 2021_0818-golden | grep Committed
svn list -R file://$SVN_ROOT/$PRJ_ID/$G > $LAB_OUT/lab09_manifest.txt
dvc_get_dqi --root $P/$G --csv --all > $LAB_OUT/lab09_signoff.csv
dvc_set_env --server NETLIST_STATE FROZEN_2021_0818
echo "   manifest 条目 = `wc -l < $LAB_OUT/lab09_manifest.txt`   状态 = `dvc_get_env --server NETLIST_STATE`"

echo "==================== 进度总览（周会就用这一屏）"
echo "  PHASES    : `dvc_list_project $PRJ_ID | tr '\n' ' '`"
echo "  P1-blocks : `dvc_list_phase P1-trial | tr '\n' ' '`"
dvc_set_folder P2-stable/cpu/400-APR > /dev/null
echo "  cpu stages: `dvc_list_block | tr '\n' ' '`"
echo "  APR 版本  : `dvc_list_stage | tr '\n' ' '`"
echo "[CHECK] 六个流程节点 + 交付凭据全部由同一套目录语义承载，可用命令复查"
