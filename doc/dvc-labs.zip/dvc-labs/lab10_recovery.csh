#!/bin/csh -f
# lab10 · 危险操作、恢复与迁移（自包含：只用自己新建的版本，避免跨 lab 复用工作副本）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh
set W = $TRAIN_ROOT/users/u10
mkdir -p $W; cd $W
dvc_checkout_project $PRJ_ID _ > /dev/null
set SVD = file://$SVN_ROOT/$PRJ_ID
set V   = P1-trial/chip/000-DATA/2021_0310-lab10

echo "##### STEP 0  现代 SVN 只有一个 .svn：卡住时的第一招是 svn cleanup"
dvc_create_folder $V | grep 'Create Project Design Version'
dvc_set_dqi --root _/_/_/$V:t > /dev/null
dvc_checkout_folder $V > /dev/null
svn cleanup _                     # 递归清理整个检出根
echo "   已对 _ 执行 svn cleanup"

echo "##### STEP 1  正常入库一份文件，并记下修订号"
dvc_copy_object $LAB_DATA/cpu.v keepme.v | tail -1
dvc_copy_object $LAB_DATA/cpu.sdc keepme.sdc | tail -1
dvc_checkin_version 2021_0310-lab10 | grep -E "Adding|Committed"
set R1 = `svn log -l 1 --quiet $SVD/$V/keepme.v | grep -o '[0-9]*' | head -1`
echo "   两个文件的入库修订号 = r$R1"

echo "##### STEP 2  误删一个文件（delete + commit），然后找回"
dvc_delete_object keepme.sdc | tail -1
svn cleanup _ ; dvc_commit_container . | grep -E "Deleting|Committed"
echo "--- 服务器现在还有几个文件：" `svn list $SVD/$V | wc -l`
echo "--- 找回被删文件：peg revision 写法 URL@修订号（不是 -r）"
svn cat $SVD/$V/keepme.sdc@$R1 > $LAB_OUT/recovered_keepme.sdc
wc -c < $LAB_OUT/recovered_keepme.sdc | awk '{print "      恢复字节 =",$1}'
echo "--- 或者把它请回工作副本并重新提交："
if ( -d "_/$V" ) then
    svn copy $SVD/$V/keepme.sdc@$R1 "_/$V/keepme.sdc" | tail -1
endif
svn cleanup _ ; dvc_checkin_version 2021_0310-lab10 > /dev/null
echo "   恢复后文件数：" `svn list $SVD/$V | wc -l`

echo "##### STEP 3  版本作废 vs 项目删除（危险等级）"
dvc_remove_version 2021_0310-lab10 | grep -E "Remove|Committed"
echo "--- stage 下已看不到：       " `dvc_list_stage 000-DATA | tr '\n' ' '`
echo "--- 但删除前它完整存在（同一 peg 写法）：" `svn ls $SVD/$V@$R1 | tr '\n' ' '`
echo "   危险分级："
echo "     clean_container  → 清容器对象+提交（历史可回）"
echo "     remove_version   → 删版本目录+提交（历史可回）"
echo "     remove_project   → rm -rf SVN_ROOT/<项目>（历史一起没了！）"

echo "##### STEP 4  整库备份 / 迁移（对外交接与容灾的标准做法）"
svnadmin dump $SVN_ROOT/$PRJ_ID > $LAB_OUT/$PRJ_ID.dump
gzip -1 -f $LAB_OUT/$PRJ_ID.dump
echo "   dump 压缩后 = " `du -k $LAB_OUT/$PRJ_ID.dump.gz | awk '{print $1}'` "KB，修订总数 = " `svnadmin lstgns $SVN_ROOT/$PRJ_ID | wc -l`
ls -l /dev/null | awk '{printf "   dump 压缩后 = %.1f KB（含 %s 个修订）\n", $5/1024, "'"}'
set NEW = $TRAIN_ROOT/migrated
rm -rf $NEW; mkdir -p $NEW/svn
svnadmin create $NEW/svn/$PRJ_ID
gunzip -c $LAB_OUT/$PRJ_ID.dump.gz | svnadmin load $NEW/svn/$PRJ_ID >& /dev/null
echo "--- 迁移后的仓库直接可被 dvc 读取（换 SVN_ROOT 而已）："
dvc_set_env SVN_ROOT $NEW/svn
dvc_init_server --root $NEW/svn --mode file >& /dev/null
echo "   " `dvc_get_server --info | grep SVN_URL` " -> " `dvc_list_project $PRJ_ID | tr '\n' ' '`
echo "--- 恢复本 lab 的上下文，交给 verify.csh 做最终自检"
rm -f .dop/env/SVN_ROOT
source $LAB_HOME/env.csh > /dev/null

echo "[CHECK] 1) 卡住先 svn cleanup 2) 删除不是丢数据，commit 历史才是资产 3) remove_project 是唯一不可回的操作 4) 交接用 dump/load"
