#!/bin/csh -f
# lab08 · 跨团队共享（第一层）：同一仓库、两个工作区、按需取数
#   角色 A = 交付方（core 团队，用户目录 users/u01）
#   角色 B = 接收方（封装团队，工作区 work/pkgA）
set _self = `dirname "$0"`
setenv LAB_HOME `cd $_self && pwd`
source $LAB_HOME/env.csh

echo "##### STEP 1  交付方：铺一条 golden 交付路径（沿用 lab05 已验证的动作）"
cd $TRAIN_ROOT/users/u01
dvc_create_folder P3-final/chip/700-TAPEOUT/2021_0818-golden | grep "Create Project Design Version"
dvc_checkout_folder  P3-final/chip/700-TAPEOUT/2021_0818-golden | grep "Checkout Project Design Version"
dvc_copy_object $LAB_DATA/cpu.v  chip.v | tail -1
dvc_copy_object $LAB_DATA/cpu.sdc constraint.sdc | tail -1
dvc_copy_object $LAB_DATA/reports/ report | tail -1
dvc_set_dqi --root :version WNS -0.008 | tail -1
dvc_set_dqi --root :version DRC 0 | tail -1
dvc_checkin_version 2021_0818-golden | grep -E "Adding|Committed" | tail -3

echo "##### STEP 2  交付凭据三件套：清单 + 质量快照 + 状态标记"
set SVD = file://$SVN_ROOT/$PRJ_ID
svn list -R $SVD/P3-final/chip/700-TAPEOUT/2021_0818-golden > $LAB_OUT/lab08_manifest.txt
echo "   manifest 条目数 = `wc -l < $LAB_OUT/lab08_manifest.txt`"
head -4 $LAB_OUT/lab08_manifest.txt
dvc_get_dqi --root $TRAIN_ROOT/users/u01/_/P3-final/chip/700-TAPEOUT/2021_0818-golden --csv --all | tr '\n' ' '; echo
dvc_set_env --server NETLIST_STATE FROZEN_2021_0818
dvc_get_env --server NETLIST_STATE

echo "##### STEP 3  接收方：不需要跑工具，只要地址 + 一条检出命令"
set B = $TRAIN_ROOT/work/pkgA
mkdir -p $B; cd $B
dvc_get_server --info | grep -E "SVN_MODE|SVN_URL|SVN_ROOT"
dvc_set_project $PRJ_ID
dvc_list_project $PRJ_ID | tr '\n' ' '; echo
dvc_checkout_project $PRJ_ID _ | grep "INFO: Checkout"
dvc_checkout_folder P3-final/chip/700-TAPEOUT/2021_0818-golden | grep -E "Checkout Project Design Version|Container"
dvc_get_folder --info
echo "--- 元数据一起进来了（所以对方能复原语义）："
ls -a :version | head -6

echo "##### STEP 4  接收方只取需要的那部分（省时间的关键）"
echo "--- 默认 files 深度下版本目录里有："; ls :version
echo "--- 要实体文件时，两种做法："
echo "   a) 加深检出： dvc_checkout_version --depth infinity 2021_0818-golden"
dvc_checkout_version --depth infinity 2021_0818-golden | grep "Checkout Project Design Version"
ls :version
echo '   b) 只要一个文件： svn cat $SVN_URL/<路径> > ./chip.v'
svn cat $SVD/P3-final/chip/700-TAPEOUT/2021_0818-golden/chip.v > ./chip_copy.v
ls -l chip_copy.v | awk '{print "      取回", $5, "bytes ->", $9}'

echo "##### STEP 5  接收方回写：另建自己的版本，绝不动 golden"
dvc_create_version 2021_0820-pkgchk | grep "Create Project Design Version"
dvc_checkout_version 2021_0820-pkgchk | grep "Checkout Project Design Version"
dvc_copy_object $LAB_DATA/ip_list.csv pkg_notes.csv | tail -1
dvc_checkin_version 2021_0820-pkgchk | grep Committed
dvc_list_stage 700-TAPEOUT

echo "[CHECK] 1) 共享=同一仓库+对方自己的上下文，不是拷目录 2) manifest/.dqi/状态变量是交付凭据 3) golden 只读，回写走新 Version"
